// navbar





//top emage delete section
$("#delete1").click(function () {
    $("#test1").css("display", "none");
});

$("#delete2").click(function () {
    $("#test2").css("display", "none");
});

$("#delete3").click(function () {
    $("#test3").css("display", "none");
});

$("#delete4").click(function () {
    $("#test4").css("display", "none");
});


$("#delete5").click(function () {
    $("#test5").css("display", "none");
});




// award section
$("#daw01").click(function () {
    $("#aw01").css("display", "none");
});

$("#daw02").click(function () {
    $("#aw02").css("display", "none");
});

$("#daw03").click(function () {
    $("#aw03").css("display", "none");
});

$("#daw04").click(function () {
    $("#aw04").css("display", "none");
});

$("#daw05").click(function () {
    $("#aw05").css("display", "none");
});

$("#daw06").click(function () {
    $("#aw06").css("display", "none");
});

$("#daw07").click(function () {
    $("#aw07").css("display", "none");
});

$("#daw08").click(function () {
    $("#aw08").css("display", "none");
});

$("#daw09").click(function () {
    $("#aw09").css("display", "none");
});

$("#daw10").click(function () {
    $("#aw10").css("display", "none");
});

$("#daw11").click(function () {
    $("#aw11").css("display", "none");
});

$("#daw12").click(function () {
    $("#aw12").css("display", "none");
});

$("#daw13").click(function () {
    $("#aw13").css("display", "none");
});

$("#daw14").click(function () {
    $("#aw14").css("display", "none");
});

$("#daw15").click(function () {
    $("#aw15").css("display", "none");
});

$("#daw16").click(function () {
    $("#aw16").css("display", "none");
});

$("#daw17").click(function () {
    $("#aw17").css("display", "none");
});

$("#daw18").click(function () {
    $("#aw18").css("display", "none");
});








// edit events update section
//delete event on  event update section
$("#eued01").click(function () {
    $("#eue01").css("display", "none");
});

$("#eued02").click(function () {
    $("#eue02").css("display", "none");
});

$("#eued03").click(function () {
    $("#eue03").css("display", "none");
});

$("#eued04").click(function () {
    $("#eue04").css("display", "none");
});

$("#eued05").click(function () {
    $("#eue05").css("display", "none");
});

$("#eued06").click(function () {
    $("#eue06").css("display", "none");
});

$("#eued07").click(function () {
    $("#eue07").css("display", "none");
});

$("#eued08").click(function () {
    $("#eue08").css("display", "none");
});

$("#eued09").click(function () {
    $("#eue09").css("display", "none");
});








// edit members update section
//delete a member on member update section
$("#momsd01").click(function () {
    $("#moms01").css("display", "none");
});

$("#momsd02").click(function () {
    $("#moms02").css("display", "none");
});

$("#momsd03").click(function () {
    $("#moms03").css("display", "none");
});

$("#momsd04").click(function () {
    $("#moms04").css("display", "none");
});

$("#momsd05").click(function () {
    $("#moms05").css("display", "none");
});
